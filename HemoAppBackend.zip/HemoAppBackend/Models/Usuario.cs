namespace HemoAppApi.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Location { get; set; }
        public string BloodType { get; set; }
        public DateTime BirthDate { get; set; }
        public double Weight { get; set; }
        public string Bio { get; set; }
        public string Rg { get; set; }
        public string Cpf { get; set; }
    }
}
